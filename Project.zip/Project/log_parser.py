import win32evtlog  # Windows Event Log access
import re           # For Regex pattern matching
import sys
import csv          # For writing CSV output

# 🔍 Step 1: Read Windows Event Logs
def read_event_log(log_type="Security"):
    server = None  # Local machine
    try:
        log_handle = win32evtlog.OpenEventLog(server, log_type)
    except Exception as e:
        print(f"❌ Admin Privilege Error: {e}")
        print("🔑 Please run this script as Administrator.")
        sys.exit()

    flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
    events = []

    try:
        while True:
            events_batch = win32evtlog.ReadEventLog(log_handle, flags, 0)
            if not events_batch:
                break
            for event in events_batch:
                events.append(event)
    finally:
        win32evtlog.CloseEventLog(log_handle)

    return events

# 🔒 Step 2: Define Regex Patterns for Threats
def detect_threats(events):
    threat_patterns = {
        "Brute Force": r"4625.*(Logon Type 3|Logon Type 10)",  # Failed login from network or RDP
        "Privilege Escalation": r"4672",                       # Special privileges assigned
        "Encoded PowerShell": r"powershell\.exe.*-enc",        # Suspicious PowerShell
        "User Creation": r"4720",                              # New user account created
        "Admin Group Add": r"4732.*Administrators"             # Added to Admin group
    }

    threats_found = []
    for event in events:
        message = str(event.StringInserts)
        for threat_name, pattern in threat_patterns.items():
            if re.search(pattern, message, re.IGNORECASE):
                threats_found.append((threat_name, message))
    return threats_found

# 🧪 Step 3: Run Script
if __name__ == "__main__":
    events = read_event_log()
    threats = detect_threats(events)

    if threats:
        print("🚨 Threats Detected:")
        
        # Save to TXT
        with open("threat_report.txt", "w") as f_txt:
            for threat, msg in threats:
                truncated_msg = msg[:150].replace("\n", " ")
                print(f"- {threat}: {truncated_msg}...")
                f_txt.write(f"{threat}: {truncated_msg}\n")
        print("📝 Threat report saved to threat_report.txt")

        # Save to CSV
        with open("threat_report.csv", "w", newline='') as f_csv:
            writer = csv.writer(f_csv)
            writer.writerow(["Threat Type", "Message"])
            for threat, msg in threats:
                writer.writerow([threat, msg[:300].replace("\n", " ")])
        print("📁 CSV report saved as threat_report.csv")

    else:
        print("✅ No threats detected.")
